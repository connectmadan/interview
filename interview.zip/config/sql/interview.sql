-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2017 at 03:36 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `interview`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(21, '2014_10_12_000000_create_users_table', 1),
(22, '2014_10_12_100000_create_password_resets_table', 1),
(23, '2017_06_09_020407_create_roles_table', 1),
(24, '2017_06_09_021913_add_role_id_to_users_table', 1),
(25, '2017_06_09_104130_create_user_images_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', '2017-06-08 18:30:00', NULL),
(2, 'Manager', NULL, NULL),
(3, 'User', '2017-06-08 18:30:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role_id` int(11) NOT NULL DEFAULT '0',
  `reporting_manager_id` int(11) NOT NULL DEFAULT '0',
  `created_by_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `role_id`, `reporting_manager_id`, `created_by_id`) VALUES
(1, 'Madan Kumar Ray', 'connectmadan@gmail.com', '$2y$10$GjVoK8i54WriHMeLKSvp6.mJ8bFs1/GnUMEPBk/oO3VAt5ZQXxaOG', 'Ma8tZVHbHjXjQOZMXaaUtJPUQ0DyXVpk4SKM1D4sbsU5k2nvjJmLBHOU00SR', '2017-06-09 05:17:34', '2017-06-09 05:17:34', 1, 1, 1),
(2, 'Raj Kumar', 'raj@gmail.com', '$2y$10$7x1r92ml8yMVQIjiv518FO27ytJuhIKffFsdTFTRcEw01nmk5sj.m', NULL, '2017-06-09 05:19:46', '2017-06-09 05:19:46', 2, 1, 1),
(3, 'Rakesh', 'rakesh@gmail.com', '$2y$10$JOh.LyYNoWaN0kpwcIJBMeGY3YyqLIwSX8D5ckAbpK6yyhA3mEW8y', NULL, '2017-06-09 05:48:25', '2017-06-09 05:48:25', 2, 1, 0),
(4, 'Rajiv', 'rajiv@gmail.com', '$2y$10$n87BQ9HzOSdoJ2e/AcCBx.nWt4qhexRHiweDlDJNBdMRLo5MmjyDO', '5cCju96aC2Zq0OunPuidhCXbK47ndBwBNlgQAcmOPGYRNtYy7ajl2AF0H4Uu', '2017-06-09 05:49:18', '2017-06-09 05:49:18', 2, 1, 0),
(5, 'asfd', 'asf@gmail.com', '$2y$10$35zRiB/9uo.UU7H8pJQI/OEKfl/eaM3ti1ofOg5uyJxgQNjX4tToe', NULL, '2017-06-09 05:50:40', '2017-06-09 05:50:40', 1, 1, 0),
(6, 'asdf', 'asdfassss@gmail.com', '$2y$10$fv.B4.y4sVyjz6nJ/icoK.X98zCQqUg40jXL0BpE4cDYiHUUwJ522', NULL, '2017-06-09 05:52:33', '2017-06-09 05:52:33', 1, 1, 0),
(7, 'manohar', 'manohar@gmail.com', '$2y$10$pf4q8cWF.47dCuZ7K24VwuQg4s/LD2hcdLNfidSN6aRGwIOWju.Y6', NULL, '2017-06-09 05:54:14', '2017-06-09 05:54:14', 2, 1, 4),
(8, 'Ramnath', 'ramnath@gmail.com', '$2y$10$s5W88DVafdmyzTeKEYvYS.SnLQt26HXT2OLieB0lMxQoBWbwbU/C.', NULL, '2017-06-09 07:46:30', '2017-06-09 07:46:30', 2, 1, 4),
(10, 'Raghav', 'raghav@gmail.com', '$2y$10$mr.2jL.ZaVSTIMfX2GTMZ.S3N0ojZOGvsfThxWqizlIP17btdNlya', 'v2b2caVcfEKoNZq5ryshlHeyufa6MBCE1ryjajKPvzNxuwfOYgLqqPQIHjTZ', '2017-06-09 08:02:23', '2017-06-09 08:02:23', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_images`
--

CREATE TABLE `user_images` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_thumb_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_images`
--

INSERT INTO `user_images` (`id`, `user_id`, `user_name`, `image_name`, `image_thumb_name`, `created_at`, `updated_at`) VALUES
(1, 4, 'Ram niwas', 'userimage/cte1hsjNHdbyBxPRAwJ6rvmUPSjoHuG5V1vfap5w.jpeg', 'userimage/cte1hsjNHdbyBxPRAwJ6rvmUPSjoHuG5V1vfap5w.jpeg', '2017-06-09 07:00:24', '2017-06-09 07:00:24'),
(2, 4, 'Mohan', 'userimage/obz77az8y0Jh7TNoMFeIq0i5qX9MGHUaY8Z2RY99.jpeg', 'userimage/obz77az8y0Jh7TNoMFeIq0i5qX9MGHUaY8Z2RY99.jpeg', '2017-06-09 07:32:18', '2017-06-09 07:32:18'),
(3, 1, 'dasfas', 'userimage/e3FEwEVCqyUI8gXi3Z86yBlxhKHqt6cbhqZA1ouU.jpeg', 'userimage/e3FEwEVCqyUI8gXi3Z86yBlxhKHqt6cbhqZA1ouU.jpeg', '2017-06-09 07:40:17', '2017-06-09 07:40:17'),
(4, 4, 'Text 2', 'userimage/FfOcL52n9JwVpcJyt0wYWNbj7hvT52QCLJt57lKB.jpeg', 'userimage/FfOcL52n9JwVpcJyt0wYWNbj7hvT52QCLJt57lKB.jpeg', '2017-06-09 07:44:50', '2017-06-09 07:44:50'),
(5, 1, 'sadfasf', 'userimage/h4etcYOWcdi2s6yhx9BRsXX8buiqQy2L3U97tv6W.jpeg', 'userimage/h4etcYOWcdi2s6yhx9BRsXX8buiqQy2L3U97tv6W.jpeg', '2017-06-09 07:47:13', '2017-06-09 07:47:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_title_unique` (`title`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_images`
--
ALTER TABLE `user_images`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `user_images`
--
ALTER TABLE `user_images`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
