<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading col-md-3" style="border-bottom:none;"><strong>Users</strong></div>
				<div class="col-md-9"><a href="/users/add" class="btn btn-primary pull-right">Add Image</a></div>
                <div class="panel-body">
                    <table class="table table-bordered table-striped datatable" id="table-2">
                        <thead>
                            <tr>                                
                                <th width="20">S.No.</th>
                                <th>Name</th>
                                <th>Image</th>
                                <th>Uploaded by</th>
                                <th width="30">Action</th>
                            </tr>
                        </thead>                    
                        <tbody>                    
							<?php ($i = 0); ?>
							<?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            	
                                <tr>                                    
                                    <td><?php echo e(++$i); ?></td>
                                    <td><?php echo e(ucwords($row->name)); ?></td>
                                    <td><?php echo e($row->email); ?></td>
                                    <td><?php echo e(ucwords($row->title)); ?></td>
                                    <td>
                                    <?php if($row->id!=1): ?>                                       
                                        <form method="post" action="/users/destroy/<?php echo e($row->id); ?>">
                                            <?php echo e(method_field('DELETE')); ?>

                                            
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">                               
                                                                                           
                                               
                                               <button onclick="javascript:confirm('Do you want to delete it?');" type="submit" class="btn btn-danger">Delete</button>
                                              
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>