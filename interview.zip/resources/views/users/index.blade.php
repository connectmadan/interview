@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading col-md-3" style="border-bottom:none;"><strong>Users</strong></div>
				<div class="col-md-9"><a href="/users/add" class="btn btn-primary pull-right">Add User</a></div>
                <div class="panel-body">
                    <table class="table table-bordered table-striped datatable" id="table-2">
                        <thead>
                            <tr>                                
                                <th width="20">S.No.</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th width="30">Action</th>
                            </tr>
                        </thead>                    
                        <tbody>                    
							@php ($i = 0)
							@foreach ($users as $row)                            	
                                <tr>                                    
                                    <td>{{ ++$i }}</td>
                                    <td>{{ ucwords($row->name) }}</td>
                                    <td>{{ $row->email }}</td>
                                    <td>{{ ucwords($row->title) }}</td>
                                    <td>
                                    @if($row->id!=1)                                       
                                        <form method="post" action="/users/destroy/{{ $row->id }}">
                                            {{ method_field('DELETE') }}
                                            
                                            <input type="hidden" name="_token" value="{{ csrf_token() }}">                               
                                                                                           
                                               
                                               <button onclick="javascript:confirm('Do you want to delete it?');" type="submit" class="btn btn-danger">Delete</button>
                                              
                                            </form>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
