<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;


class UserImagesController extends Controller
{
    //
	
	 /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
	
	/**
     * Show the application dashboard.
     *
     * @return 
     */
    public function index()
    {		
		$photos = DB::table('user_images')->leftjoin('users', 'users.id', '=', 'user_images.user_id')->select('user_images.*', 'users.name')->where('user_images.user_id', '=', \Auth::id())->get();		
		//return $photos;
        return view('dashboard', compact('photos'));
    }
	
	 /**
     * Upload Photo
     *
     * @
     */
	 
	 public function upload(){
		return view('upload'); 
	 }	 
	 
	
	public function uploadphoto(){
		 //dd(request()->all());
		 //dd(request('image_name'));
		
		 $this->validate(request(), [
    			'user_name' => 'required',
				'image_name' => 'required'
    		]);
		$file_path = request()->file('image_name')->store('userimage');
    	\App\UserImage::create([
            'user_name' => request('user_name'),
            'image_name' => $file_path,
			'image_thumb_name' => $file_path,           
			'user_id' => \Auth::id(),
        ]);
    	return redirect('/dashboard'); 
	 }
}
