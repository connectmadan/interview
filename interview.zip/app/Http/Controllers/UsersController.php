<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\User;
//use App\Roles;

class UsersController extends Controller
{
    //
	
	
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {        
		$this->middleware('auth');			
    }
	
    /**
     * role options.
     *
     * @param  selected
     * @return options
     */
   	private static function roleOptions($selected = ''){
		//dd(request('role_id'));
		if(!empty(request('role_id'))){
			$selected = request('role_id');	
		}
		
		$roles = \App\Roles::pluck('title', 'id')->toArray();
		$options = '<option value="">Select one</option>';
		if(count($roles)){
			foreach($roles as $key => $val){
				$options .= '<option value="'.$key.'" ';
				if($selected == $key){
					$options .= 'selected="selected" ';
				}
				
				$options .= '>'.$val.'</option>';
			}
		}
		
		return $options;
	}
	
	 /**
     * Reporting manager options.
     *
     * @param  selected
     * @return options
     */
   	private static function reportingManagerOptions($selected = '', $role_id=''){
		//dd(request('role_id'));
		if(!empty(request('reporting_manager_id'))){
			$selected = request('reporting_manager_id');	
		}
		
		if(!empty(request('role_id'))){
			$role_id = request('role_id');	
		}
		
		if($role_id==1 or $role_id==2){
			$users = \App\User::where('role_id', '=', 1)->pluck('name', 'id')->toArray();
		}elseif($role_id==3){
			$users = \App\User::where('role_id', '=', 2)->pluck('name', 'id')->toArray();
		}else{
			$users = \App\User::where('role_id', '<', 3)->pluck('name', 'id')->toArray();
		}
				
		$options = '<option value="">Select one</option>';
		if(count($users)){
			foreach($users as $key => $val){
				$options .= '<option value="'.$key.'" ';
				if($selected == $key){
					$options .= 'selected="selected" ';
				}
				
				$options .= '>'.$val.'</option>';
			}
		}
		
		return $options;
	}
	
	protected function add()
    {
		$roles = self::roleOptions('');
		$reporting_managers = self::reportingManagerOptions('', '');		
		return view('users.add', compact('roles', 'reporting_managers'));        		
    }
	
	public function store(){
    	//dd(request()->all());		
    	$this->validate(request(), [
    			'role_id' => 'required',
    			'reporting_manager_id' => 'required',
				'name' => 'required|string|max:255',
				'email' => 'required|string|email|max:255|unique:users',
				'password' => 'required|string|min:6|confirmed'
    		]);
    	\App\User::create([
            'name' => request('name'),
            'email' => request('email'),
            'password' => bcrypt(request('password')),
			'role_id' => request('role_id'),
			'reporting_manager_id' => request('reporting_manager_id'),
			'created_by_id' => \Auth::id(),
        ]);
    	return redirect('/users');
    }
	
	/**
     * Show the application users.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		//return \Auth::id();
		$users = DB::table('users')->leftjoin('roles', 'users.role_id', '=', 'roles.id')->where('users.created_by_id', '=', \Auth::id())->select('users.*', 'roles.title')->get();		
		return view('users.index', compact('users'));
    }
	
	public function destroy($id){
		$user = \App\User::find($id);
		//return $user;
		$user->delete();
		return redirect('/users');
	}
}
